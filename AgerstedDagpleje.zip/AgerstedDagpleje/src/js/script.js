$(document).ready(function()
{

	$('.burgerMenu').click(function ()
	{
		$('.burgerMenuNav, .menuCenter').addClass( "open");

	});

	$('.close').click(function ()
	{
		$('.burgerMenuNav, .menuCenter').removeClass( "open");

	});

	
		
});