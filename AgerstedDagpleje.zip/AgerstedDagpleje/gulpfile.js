var gulp = require('gulp');
var sass = require('gulp-sass');
var watch = require('gulp-watch');
var useref = require('gulp-useref');
// minify js
var uglify = require('gulp-uglify');
var gulpIf = require('gulp-if');
// minify css
var cssnano = require('gulp-cssnano');
// run sequence
var runSequence = require('run-sequence');


gulp.task('sass', function(){
  return gulp.src('src/scss/**/*.scss')
    .pipe(sass()) // Using gulp-sass
    .pipe(gulp.dest('dist/css'))
});

gulp.task('watch', function(){
  gulp.watch('src/scss/**/*.scss', ['sass'])
  gulp.watch('src/css/**/*.css', ['default'])
   gulp.watch('/*.html', ['default'])  
  // Other watchers
})


gulp.task('useref', function(){
  return gulp.src('*.html')
    .pipe(useref())
    .pipe(gulpIf('*.js', uglify()))
     .pipe(gulpIf('*.css', cssnano()))
    .pipe(gulp.dest('dist'))
});


gulp.task('default', function (callback) {
  runSequence(['sass','useref', 'watch'],
    callback
  )
})

